from pyspark.sql.functions import *


def run_quality_checks(spark):

    df = spark.table(
        "azure_databricks1.default.silver_rides"
    )

    row_count = df.count()

    required_columns = [
        "Booking_ID",
        "Booking_Status",
        "Vehicle_Type",
        "Booking_Value",
        "Ride_Distance",
        "Payment_Method"
    ]

    null_counts = df.select(
        [
            count(
                when(col(c).isNull(), 1)
            ).alias(c)
            for c in required_columns
        ]
    ).first().asDict()

    invalid_booking_value = df.filter(
        col("Booking_Value").isNull()
        | (col("Booking_Value") <= 0)
    ).count()

    invalid_distance = df.filter(
        col("Ride_Distance").isNull()
        | (col("Ride_Distance") <= 0)
    ).count()

    passed = (
    row_count > 0
    and null_counts["Booking_ID"] == 0
    and null_counts["Booking_Status"] == 0
    and null_counts["Vehicle_Type"] == 0
    and null_counts["Payment_Method"] == 0
)

    return {
        "status": "passed" if passed else "failed",
        "row_count": row_count,
        "null_counts": null_counts,
        "invalid_booking_value": invalid_booking_value,
        "invalid_distance": invalid_distance
    }