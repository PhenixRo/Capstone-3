from pyspark.sql.functions import *
from config import source_path


def read_source(spark):

    raw_df = spark.read.csv(
        source_path,
        header=True,
        inferSchema=True
    )

    return raw_df


def build_bronze(spark, raw_df):

    bronze_df = raw_df

    # Rename columns to Delta-compatible names
    for col_name in bronze_df.columns:
        bronze_df = bronze_df.withColumnRenamed(
            col_name,
            col_name.strip()
                    .replace(" ", "_")
                    .replace("-", "_")
                    .replace("/", "_")
        )

    bronze_df = bronze_df.withColumn(
        "ingestion_timestamp",
        current_timestamp()
    )

    bronze_df.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable("azure_databricks1.default.bronze_rides")

    bronze_df = spark.table(
        "azure_databricks1.default.bronze_rides"
    )

    return bronze_df


def build_silver(spark, bronze_df):

    silver_df = bronze_df.dropDuplicates()

    silver_df = silver_df.withColumn(
        "Booking_Value",
        expr(
            "try_cast(regexp_replace(Booking_Value,'[^0-9.]','') as double)"
        )
    )

    silver_df = silver_df.withColumn(
        "Ride_Distance",
        expr(
            "try_cast(regexp_replace(Ride_Distance,'[^0-9.]','') as double)"
        )
    )

    silver_df = silver_df.withColumn(
        "Driver_Ratings",
        expr(
            "try_cast(regexp_replace(Driver_Ratings,'[^0-9.]','') as double)"
        )
    )

    silver_df = silver_df.withColumn(
        "Customer_Rating",
        expr(
            "try_cast(regexp_replace(Customer_Rating,'[^0-9.]','') as double)"
        )
    )

    silver_df = silver_df.filter(
        col("Booking_ID").isNotNull()
    )

    silver_df.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable("azure_databricks1.default.silver_rides")

    silver_df = spark.table(
        "azure_databricks1.default.silver_rides"
    )

    return silver_df


def build_gold(spark, silver_df):

    booking_summary_df = silver_df.groupBy(
        "Booking_Status"
    ).agg(
        count("*").alias("total_bookings"),
        sum("Booking_Value").alias("total_revenue"),
        avg("Ride_Distance").alias("avg_distance")
    )

    booking_summary_df.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable(
            "azure_databricks1.default.gold_booking_status"
        )

    vehicle_summary_df = silver_df.groupBy(
        "Vehicle_Type"
    ).agg(
        count("*").alias("total_bookings"),
        sum("Booking_Value").alias("total_revenue"),
        avg("Driver_Ratings").alias("avg_driver_rating"),
        avg("Customer_Rating").alias("avg_customer_rating")
    )

    vehicle_summary_df.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable(
            "azure_databricks1.default.gold_vehicle_type"
        )

    payment_summary_df = silver_df.groupBy(
        "Payment_Method"
    ).agg(
        count("*").alias("total_bookings"),
        sum("Booking_Value").alias("total_revenue")
    )

    payment_summary_df.write \
        .format("delta") \
        .mode("overwrite") \
        .saveAsTable(
            "azure_databricks1.default.gold_payment_method"
        )

    return {
        "booking_summary": booking_summary_df,
        "vehicle_summary": vehicle_summary_df,
        "payment_summary": payment_summary_df
    }


def run_etl(spark):

    raw_df = read_source(spark)

    bronze_df = build_bronze(
        spark,
        raw_df
    )

    silver_df = build_silver(
        spark,
        bronze_df
    )

    gold_dfs = build_gold(
        spark,
        silver_df
    )

    return {
        "status": "success",
        "bronze_rows": bronze_df.count(),
        "silver_rows": silver_df.count(),
        "booking_summary_rows": gold_dfs["booking_summary"].count(),
        "vehicle_summary_rows": gold_dfs["vehicle_summary"].count(),
        "payment_summary_rows": gold_dfs["payment_summary"].count()
    }