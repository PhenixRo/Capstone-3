from pyspark.sql.functions import *


def get_gold_metrics(spark):

    booking_df = spark.table(
        "azure_databricks1.default.gold_booking_status"
    )

    vehicle_df = spark.table(
        "azure_databricks1.default.gold_vehicle_type"
    )

    payment_df = spark.table(
        "azure_databricks1.default.gold_payment_method"
    )

    overall = booking_df.agg(
        sum("total_bookings").alias("total_bookings"),
        sum("total_revenue").alias("total_revenue")
    ).first().asDict()

    if overall["total_bookings"]:
        overall["average_booking_value"] = (
            overall["total_revenue"] /
            overall["total_bookings"]
        )
    else:
        overall["average_booking_value"] = None

    top_vehicle_types = [
        row.asDict()
        for row in vehicle_df.orderBy(
            desc("total_bookings")
        ).limit(10).collect()
    ]

    payment_summary = [
        row.asDict()
        for row in payment_df.orderBy(
            "Payment_Method"
        ).collect()
    ]

    return {
        "overall": overall,
        "top_vehicle_types": top_vehicle_types,
        "payment_summary": payment_summary
    }