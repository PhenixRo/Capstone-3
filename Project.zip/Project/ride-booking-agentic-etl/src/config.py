# For spark-cluster
#storage_account_name = "azurestoragedemo01"
#container_name = "green-trip-taxi"
# Paste your newly rotated storage key here.
#storage_account_key = "1X2tyMVzybQwFWqM10FsaANxv9DMitV7qSf8wP78h5/bXLjAEnTO56bNZ+GH6uFKU2VMq4UKvVuE+AStv7S17Q=="
 
# For serverless - no need of storage_account_name, container_name, storage_account_key
 
# Paste your Microsoft Foundry API key here.
foundry_api_key = "T5vmbLBVMJEzxr8P86Ya3xZvtDNTCgXrDlwDYpVsX85Op90coxKtJQQJ99CJACYeBjFXJ3w3AAAAACOGafWO"
foundry_endpoint = "https://azure-foundary1.services.ai.azure.com/openai/v1"
foundry_model = "gpt-5-mini"
 
# for spark-cluster
#storage_base = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net"
 
# for serverless
source_path = "file:/Workspace/Project/ride-booking-agentic-etl/data/uber-rides/ncr_ride_bookings.csv"


base_path = "dbfs:/tmp/green_taxi"

bronze_path = f"{base_path}/bronze"
silver_path = f"{base_path}/silver"

gold_daily_path = f"{base_path}/gold/daily"
gold_location_path = f"{base_path}/gold/location"
gold_payment_path = f"{base_path}/gold/payment"
# "/Workspace/green-taxi-agentic-etl/data"
 