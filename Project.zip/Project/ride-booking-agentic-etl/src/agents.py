from typing import TypedDict

from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END

from config import (
    foundry_endpoint,
    foundry_api_key,
    foundry_model
)

from etl_pipeline import run_etl
from quality_checks import run_quality_checks
from gold_analytics import get_gold_metrics


llm = ChatOpenAI(
    model=foundry_model,
    base_url=foundry_endpoint,
    api_key=foundry_api_key,
    temperature=0.7,
    max_retries=2,
    timeout=60
)


class ETLState(TypedDict, total=False):
    query: str
    route: str
    etl_result: dict
    quality_result: dict
    analytics_result: dict
    answer: str


def build_agent_graph(spark):

    def supervisor_agent(state: ETLState):

        query = state["query"].lower()

        try:
            prompt = f"""
            You are the supervisor of a Ride Booking ETL system.

            The dataset contains:
            - Booking Status
            - Vehicle Type
            - Booking Value
            - Ride Distance
            - Customer Rating
            - Driver Ratings
            - Payment Method

            Choose exactly one route:

            run_etl
            quality
            analytics
            explain

            User request:
            {state['query']}

            Return only the route name.
            """

            response = llm.invoke(prompt)
            route = response.content.strip().lower()

        except Exception:
            route = ""

        if route not in {
            "run_etl",
            "quality",
            "analytics",
            "explain"
        }:

            if any(
                x in query
                for x in [
                    "run etl",
                    "execute etl",
                    "refresh pipeline",
                    "build pipeline"
                ]
            ):
                route = "run_etl"

            elif any(
                x in query
                for x in [
                    "quality",
                    "null",
                    "duplicate",
                    "duplicates",
                    "invalid"
                ]
            ):
                route = "quality"

            elif any(
                x in query
                for x in [
                    "analytics",
                    "revenue",
                    "payment",
                    "vehicle",
                    "booking",
                    "rating",
                    "rides",
                    "gold"
                ]
            ):
                route = "analytics"

            else:
                route = "explain"

        return {"route": route}

    def etl_agent(state: ETLState):

        try:
            result = run_etl(spark)

            return {
                "etl_result": result
            }

        except Exception as exc:

            return {
                "etl_result": {
                    "status": "failed",
                    "error": str(exc)
                }
            }

    def quality_agent(state: ETLState):

        try:
            result = run_quality_checks(spark)

            return {
                "quality_result": result
            }

        except Exception as exc:

            return {
                "quality_result": {
                    "status": "failed",
                    "error": str(exc)
                }
            }

    def analytics_agent(state: ETLState):

        try:

            metrics = get_gold_metrics(spark)

            try:

                response = llm.invoke(
                    f"""
                    You are a Ride Booking Analytics Assistant.

                    Create a business-friendly report.

                    Include:
                    1. Total Bookings
                    2. Total Revenue
                    3. Average Booking Value
                    4. Top Vehicle Types
                    5. Key Business Insight

                    Metrics:

                    {metrics}

                    User Question:
                    {state['query']}
                    """
                )

                answer = response.content

            except Exception:

                overall = metrics["overall"]

                answer = f"""
Ride Booking Analytics Summary

Total Bookings: {overall['total_bookings']:,}

Total Revenue: ₹{overall['total_revenue']:,.0f}

Average Booking Value: ₹{overall['average_booking_value']:.2f}

Top Vehicle Types:
"""

                for vehicle in metrics["top_vehicle_types"][:5]:

                    answer += (
                        f"\n• {vehicle['Vehicle_Type']} "
                        f"({vehicle['total_bookings']} bookings, "
                        f"Revenue ₹{vehicle['total_revenue']:,.0f})"
                    )

            return {
                "analytics_result": metrics,
                "answer": answer
            }

        except Exception as exc:

            return {
                "analytics_result": {
                    "status": "failed",
                    "error": str(exc)
                },
                "answer": str(exc)
            }

    def explanation_agent(state: ETLState):

        try:

            response = llm.invoke(
                f"""
                Explain the following Ride Booking ETL question:

                {state['query']}
                """
            )

            return {
                "answer": response.content
            }

        except Exception as exc:

            return {
                "answer": f"LLM Error: {str(exc)}"
            }

    def after_etl(state: ETLState):

        result = state.get("etl_result", {})

        if result.get("status") == "success":
            return "quality"

        return "end"

    def after_quality(state: ETLState):

        if state.get("route") == "run_etl":
            return "analytics"

        return "end"

    builder = StateGraph(ETLState)

    builder.add_node("supervisor", supervisor_agent)
    builder.add_node("etl", etl_agent)
    builder.add_node("quality", quality_agent)
    builder.add_node("analytics", analytics_agent)
    builder.add_node("explain", explanation_agent)

    builder.add_edge(START, "supervisor")

    builder.add_conditional_edges(
        "supervisor",
        lambda state: state["route"],
        {
            "run_etl": "etl",
            "quality": "quality",
            "analytics": "analytics",
            "explain": "explain"
        }
    )

    builder.add_conditional_edges(
        "etl",
        after_etl,
        {
            "quality": "quality",
            "end": END
        }
    )

    builder.add_conditional_edges(
        "quality",
        after_quality,
        {
            "analytics": "analytics",
            "end": END
        }
    )

    builder.add_edge("analytics", END)
    builder.add_edge("explain", END)

    return builder.compile()