# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# dependencies = [
#   "langchain==0.3.27",
#   "langchain-core==0.3.72",
#   "langchain-community==0.3.27",
#   "langgraph==0.6.2",
#   "langchain-openai==0.3.27",
# ]
# ///
# MAGIC %pip install langchain==0.3.27 langchain-core==0.3.72 langchain-community==0.3.27 langgraph==0.6.2 langchain-openai==0.3.27

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import langchain
import langgraph
import langchain_openai

print("LangChain:", langchain.__version__)

# COMMAND ----------

import sys

sys.path.insert(
    0,
    "/Workspace/Project/ride-booking-agentic-etl/src"
)

from etl_pipeline import run_etl

# COMMAND ----------

from config import source_path

print(source_path)

df = spark.read.csv(
    source_path,
    header=True,
    inferSchema=True
)

print(df.count())
display(df.limit(5))


# COMMAND ----------

df.printSchema()

# COMMAND ----------

result = run_etl(spark)

print("ETL execution result:")
print(result)

# COMMAND ----------

import importlib
import quality_checks

importlib.reload(quality_checks)

from quality_checks import run_quality_checks

result = run_quality_checks(spark)

print(result)

# COMMAND ----------

import importlib
import gold_analytics

importlib.reload(gold_analytics)

from gold_analytics import get_gold_metrics

result = get_gold_metrics(spark)

print(result)

# COMMAND ----------

bronze_df = spark.table(
    "azure_databricks1.default.bronze_rides"
)

silver_df = spark.table(
    "azure_databricks1.default.silver_rides"
)

bronze_df.show(5, truncate=False)
silver_df.show(5, truncate=False)

spark.table(
    "azure_databricks1.default.gold_booking_status"
).show(10, truncate=False)

spark.table(
    "azure_databricks1.default.gold_vehicle_type"
).show(10, truncate=False)

spark.table(
    "azure_databricks1.default.gold_payment_method"
).show(10, truncate=False)

# COMMAND ----------

import sys
sys.path.insert(
    0,
    "/Workspace/Project/ride-booking-agentic-etl/src"
)

from agents import build_agent_graph

etl_agent_graph = build_agent_graph(spark)

print("LangGraph ETL agents initialized")

# COMMAND ----------

# MAGIC %md
# MAGIC Execute the full ETL pipeline through the supervisor

# COMMAND ----------

# MAGIC %pip install langchain-openai langgraph langchain

# COMMAND ----------

result = etl_agent_graph.invoke({
    "query": "Run ETL on the Green Taxi CSV, "
             "validate Silver data, and analyze Gold metrics."
})

print("Selected route:", result.get("route"))
print("ETL result:", result.get("etl_result"))
print("Quality result:", result.get("quality_result"))
print("Analytics:", result.get("analytics_result"))
print("Answer:", result.get("answer"))

# COMMAND ----------

try:
    result = etl_agent_graph.invoke({
        "query": "Run ETL on the Green Taxi CSV, validate Silver data, and analyze Gold metrics."
    })
except Exception as e:
    print(type(e))
    print(e)

# COMMAND ----------

queries = [
    "Check data quality issues in the Silver layer",
    "Analyze ride booking performance and revenue",
    "What are the top vehicle types by bookings?",
    "Explain the Bronze, Silver, and Gold layers"
]

for query in queries:

    result = etl_agent_graph.invoke(
        {"query": query}
    )

    print("\nQuestion:", query)
    print("Route:", result.get("route"))
    print("Answer:", result.get("answer"))
    print("Quality report:", result.get("quality_result"))
    print("Analytics Result:", result.get("analytics_result"))

# COMMAND ----------

from langchain_openai import ChatOpenAI
from config import (
    foundry_endpoint,
    foundry_api_key,
    foundry_model
)

llm = ChatOpenAI(
    model=foundry_model,
    base_url=foundry_endpoint,
    api_key=foundry_api_key
)

response = llm.invoke("What is 2 + 2?")

print(response.content)

# COMMAND ----------

import importlib
import sys

sys.path.insert(
    0,
    "/Workspace/Project/ride-booking-agentic-etl/src"
)

import agents

importlib.reload(agents)

from agents import build_agent_graph

print("Agents imported successfully")


# COMMAND ----------

etl_agent_graph = build_agent_graph(spark)

print("Agent graph initialized")

# COMMAND ----------

result = etl_agent_graph.invoke(
    {
        "query": "Analyze ride booking performance"
    }
)

print(result["answer"])

# COMMAND ----------

# Plot the Langgraph
from IPython.display import Image, display
display(Image(etl_agent_graph.get_graph().draw_mermaid_png()))

# COMMAND ----------

