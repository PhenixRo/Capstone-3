Uber Taxi Agentic ETL Pipeline
Project Overview
This project implements an Agentic ETL Pipeline for NCR Uber Ride Booking data using Azure Databricks, PySpark, LangGraph, LangChain and Microsoft Foundry GPT.

The solution follows the Medallion Architecture (Bronze, Silver and Gold layers) to transform raw ride booking data into business-ready analytical datasets. A multi-agent workflow was developed using LangGraph to automate ETL execution, data validation, analytics generation and business explanations.

Technologies Used
PySpark
Azure Databricks
Unity Catalog
Delta Lake
LangChain
LangGraph
Microsoft Foundry GPT-5 Mini
Python
Pandas
NumPy
Project Objective
The objective of this project is to build a production-style ETL pipeline that:

Ingests NCR ride booking data
Implements Bronze, Silver and Gold layers
Performs automated data quality validation
Generates business analytics
Uses AI agents for orchestration and reporting
Integrates Microsoft Foundry GPT for intelligent explanations
Dataset
The project uses the NCR Ride Booking dataset containing approximately:

150,000 ride booking records
Key Columns
Booking_ID
Booking_Status
Customer_ID
Vehicle_Type
Pickup_Location
Drop_Location
Booking_Value
Ride_Distance
Driver_Ratings
Customer_Rating
Payment_Method
Project Structure
uber-taxi-agentic-etl/
│
├── data/
│   └── uber-rides/
│       └── ncr_ride_bookings.csv
│
├── logs/
│
├── notebooks/
│   └── setup.ipynb
│
├── src/
│   ├── config.py
│   ├── etl_pipeline.py
│   ├── quality_checks.py
│   ├── gold_analytics.py
│   └── agents.py
│
├── requirements.txt
├── README.md
└── Capstone_Project_3_Report.docx
Medallion Architecture
Bronze Layer
The Bronze layer stores raw data with ingestion metadata.

Output Table:

bronze_rides
Features:

Raw data ingestion
Ingestion timestamp generation
Initial storage of ride booking records
Silver Layer
The Silver layer performs data cleansing and standardization.

Transformations:

Duplicate removal
Column standardization
Data-type conversion
Null handling
Record validation
Output Table:

silver_rides
Gold Layer
The Gold layer provides business-ready analytical datasets.

Output Tables:

gold_booking_status
gold_vehicle_type
gold_payment_method
Analytics Generated:

Booking status analysis
Vehicle performance analysis
Revenue analysis
Payment method analysis
Data Quality Framework
The project implements automated quality validation rules.

Validation Checks
Mandatory fields validation
Duplicate record detection
Null value checks
Data consistency checks
Numeric field validation
Output:

Pass / Fail Quality Report
Multi-Agent Architecture
The project uses LangGraph to implement Agentic AI.

Supervisor Agent
Routes requests to the appropriate workflow.

ETL Agent
Executes Bronze → Silver → Gold transformations.

Quality Agent
Runs all validation checks and generates quality reports.

Analytics Agent
Generates analytical insights from Gold datasets.

Explain Agent
Provides natural language explanations and recommendations.

Microsoft Foundry Integration
Model Used:

gpt-5-mini
Foundry GPT capabilities include:

Intelligent routing
Analytics explanation
Business reporting
Natural language responses
Project Results
Processed Records
150,000 bookings
Key Metrics
Total Revenue: ₹51,846,183
Average Booking Value: ₹345.64
Vehicle Type Performance Analysis
Payment Method Analysis
Booking Status Analysis
Execution Steps
Step 1
Open Azure Databricks workspace.

Step 2
Run:

notebooks/setup.ipynb
Step 3
Execute ETL Pipeline:

from etl_pipeline import run_etl

run_etl(spark)
Step 4
Run Quality Checks:

from quality_checks import run_quality_checks

run_quality_checks(spark)
Step 5
Generate Gold Analytics:

from gold_analytics import get_gold_metrics

get_gold_metrics(spark)
Step 6
Initialize LangGraph Agents:

from agents import build_agent_graph

etl_agent_graph = build_agent_graph(spark)
Step 7
Run Agent Query:

result = etl_agent_graph.invoke(
    {
        "query": "Analyze ride booking performance"
    }
)
Future Enhancements
Real-time streaming ingestion
Demand forecasting
Fraud detection
Data drift monitoring
AI monitoring agents
Cost optimization agents


Uber Taxi Agentic ETL Pipeline